package books

class AuthorController {

    static scaffold = Author
}
