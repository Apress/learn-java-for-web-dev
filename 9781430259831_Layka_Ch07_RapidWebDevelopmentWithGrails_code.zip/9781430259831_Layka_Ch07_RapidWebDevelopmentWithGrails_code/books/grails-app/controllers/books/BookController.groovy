package books

class BookController {

    static scaffold = Book 
}
