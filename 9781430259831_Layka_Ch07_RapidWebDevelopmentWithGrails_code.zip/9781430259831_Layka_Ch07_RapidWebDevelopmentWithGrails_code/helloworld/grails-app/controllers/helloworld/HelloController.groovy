package helloworld

class HelloController {

def index() { render "Hello World" } 
}
