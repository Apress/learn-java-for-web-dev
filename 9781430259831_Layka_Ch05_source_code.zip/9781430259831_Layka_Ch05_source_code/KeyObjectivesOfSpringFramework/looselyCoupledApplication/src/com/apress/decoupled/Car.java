package com.apress.decoupled;

public class Car implements Vehicle {

	public String drive() {
		return " driving a car ";
	}

}
