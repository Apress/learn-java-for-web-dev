package com.apress.aop;

import java.util.List;

public interface BookService {
	public List<Book> getAllBooks();

}
