package com.apress.books.service;

import java.util.List;

import com.apress.books.model.Book;

public interface BookService {
	public List<Book> getAllBooks();

}
